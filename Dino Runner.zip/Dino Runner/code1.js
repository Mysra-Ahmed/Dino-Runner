gdjs.AboutCode = {};
gdjs.AboutCode.localVariables = [];
gdjs.AboutCode.GDTitleObjects1= [];
gdjs.AboutCode.GDTitleObjects2= [];
gdjs.AboutCode.GDTitleObjects3= [];
gdjs.AboutCode.GDBackgroundObjects1= [];
gdjs.AboutCode.GDBackgroundObjects2= [];
gdjs.AboutCode.GDBackgroundObjects3= [];
gdjs.AboutCode.GDStartObjects1= [];
gdjs.AboutCode.GDStartObjects2= [];
gdjs.AboutCode.GDStartObjects3= [];
gdjs.AboutCode.GDAboutObjects1= [];
gdjs.AboutCode.GDAboutObjects2= [];
gdjs.AboutCode.GDAboutObjects3= [];
gdjs.AboutCode.GDAbout_9595txtObjects1= [];
gdjs.AboutCode.GDAbout_9595txtObjects2= [];
gdjs.AboutCode.GDAbout_9595txtObjects3= [];
gdjs.AboutCode.GDBackObjects1= [];
gdjs.AboutCode.GDBackObjects2= [];
gdjs.AboutCode.GDBackObjects3= [];
gdjs.AboutCode.GDMarkerObjects1= [];
gdjs.AboutCode.GDMarkerObjects2= [];
gdjs.AboutCode.GDMarkerObjects3= [];
gdjs.AboutCode.GDBackground2Objects1= [];
gdjs.AboutCode.GDBackground2Objects2= [];
gdjs.AboutCode.GDBackground2Objects3= [];
gdjs.AboutCode.GDAbout_9595markerObjects1= [];
gdjs.AboutCode.GDAbout_9595markerObjects2= [];
gdjs.AboutCode.GDAbout_9595markerObjects3= [];


gdjs.AboutCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("About_marker"), gdjs.AboutCode.GDAbout_9595markerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Marker"), gdjs.AboutCode.GDMarkerObjects2);
{for(var i = 0, len = gdjs.AboutCode.GDMarkerObjects2.length ;i < len;++i) {
    gdjs.AboutCode.GDMarkerObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.AboutCode.GDAbout_9595markerObjects2.length ;i < len;++i) {
    gdjs.AboutCode.GDAbout_9595markerObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Back"), gdjs.AboutCode.GDBackObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.AboutCode.GDBackObjects1.length;i<l;++i) {
    if ( gdjs.AboutCode.GDBackObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.AboutCode.GDBackObjects1[k] = gdjs.AboutCode.GDBackObjects1[i];
        ++k;
    }
}
gdjs.AboutCode.GDBackObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


};gdjs.AboutCode.eventsList1 = function(runtimeScene) {

{


gdjs.AboutCode.eventsList0(runtimeScene);
}


};

gdjs.AboutCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.AboutCode.GDTitleObjects1.length = 0;
gdjs.AboutCode.GDTitleObjects2.length = 0;
gdjs.AboutCode.GDTitleObjects3.length = 0;
gdjs.AboutCode.GDBackgroundObjects1.length = 0;
gdjs.AboutCode.GDBackgroundObjects2.length = 0;
gdjs.AboutCode.GDBackgroundObjects3.length = 0;
gdjs.AboutCode.GDStartObjects1.length = 0;
gdjs.AboutCode.GDStartObjects2.length = 0;
gdjs.AboutCode.GDStartObjects3.length = 0;
gdjs.AboutCode.GDAboutObjects1.length = 0;
gdjs.AboutCode.GDAboutObjects2.length = 0;
gdjs.AboutCode.GDAboutObjects3.length = 0;
gdjs.AboutCode.GDAbout_9595txtObjects1.length = 0;
gdjs.AboutCode.GDAbout_9595txtObjects2.length = 0;
gdjs.AboutCode.GDAbout_9595txtObjects3.length = 0;
gdjs.AboutCode.GDBackObjects1.length = 0;
gdjs.AboutCode.GDBackObjects2.length = 0;
gdjs.AboutCode.GDBackObjects3.length = 0;
gdjs.AboutCode.GDMarkerObjects1.length = 0;
gdjs.AboutCode.GDMarkerObjects2.length = 0;
gdjs.AboutCode.GDMarkerObjects3.length = 0;
gdjs.AboutCode.GDBackground2Objects1.length = 0;
gdjs.AboutCode.GDBackground2Objects2.length = 0;
gdjs.AboutCode.GDBackground2Objects3.length = 0;
gdjs.AboutCode.GDAbout_9595markerObjects1.length = 0;
gdjs.AboutCode.GDAbout_9595markerObjects2.length = 0;
gdjs.AboutCode.GDAbout_9595markerObjects3.length = 0;

gdjs.AboutCode.eventsList1(runtimeScene);
gdjs.AboutCode.GDTitleObjects1.length = 0;
gdjs.AboutCode.GDTitleObjects2.length = 0;
gdjs.AboutCode.GDTitleObjects3.length = 0;
gdjs.AboutCode.GDBackgroundObjects1.length = 0;
gdjs.AboutCode.GDBackgroundObjects2.length = 0;
gdjs.AboutCode.GDBackgroundObjects3.length = 0;
gdjs.AboutCode.GDStartObjects1.length = 0;
gdjs.AboutCode.GDStartObjects2.length = 0;
gdjs.AboutCode.GDStartObjects3.length = 0;
gdjs.AboutCode.GDAboutObjects1.length = 0;
gdjs.AboutCode.GDAboutObjects2.length = 0;
gdjs.AboutCode.GDAboutObjects3.length = 0;
gdjs.AboutCode.GDAbout_9595txtObjects1.length = 0;
gdjs.AboutCode.GDAbout_9595txtObjects2.length = 0;
gdjs.AboutCode.GDAbout_9595txtObjects3.length = 0;
gdjs.AboutCode.GDBackObjects1.length = 0;
gdjs.AboutCode.GDBackObjects2.length = 0;
gdjs.AboutCode.GDBackObjects3.length = 0;
gdjs.AboutCode.GDMarkerObjects1.length = 0;
gdjs.AboutCode.GDMarkerObjects2.length = 0;
gdjs.AboutCode.GDMarkerObjects3.length = 0;
gdjs.AboutCode.GDBackground2Objects1.length = 0;
gdjs.AboutCode.GDBackground2Objects2.length = 0;
gdjs.AboutCode.GDBackground2Objects3.length = 0;
gdjs.AboutCode.GDAbout_9595markerObjects1.length = 0;
gdjs.AboutCode.GDAbout_9595markerObjects2.length = 0;
gdjs.AboutCode.GDAbout_9595markerObjects3.length = 0;


return;

}

gdjs['AboutCode'] = gdjs.AboutCode;
