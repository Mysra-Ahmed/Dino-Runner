gdjs.MenuCode = {};
gdjs.MenuCode.localVariables = [];
gdjs.MenuCode.GDTitleObjects1= [];
gdjs.MenuCode.GDTitleObjects2= [];
gdjs.MenuCode.GDTitleObjects3= [];
gdjs.MenuCode.GDBackgroundObjects1= [];
gdjs.MenuCode.GDBackgroundObjects2= [];
gdjs.MenuCode.GDBackgroundObjects3= [];
gdjs.MenuCode.GDStartObjects1= [];
gdjs.MenuCode.GDStartObjects2= [];
gdjs.MenuCode.GDStartObjects3= [];
gdjs.MenuCode.GDAboutObjects1= [];
gdjs.MenuCode.GDAboutObjects2= [];
gdjs.MenuCode.GDAboutObjects3= [];
gdjs.MenuCode.GDAbout_9595txtObjects1= [];
gdjs.MenuCode.GDAbout_9595txtObjects2= [];
gdjs.MenuCode.GDAbout_9595txtObjects3= [];
gdjs.MenuCode.GDBackObjects1= [];
gdjs.MenuCode.GDBackObjects2= [];
gdjs.MenuCode.GDBackObjects3= [];
gdjs.MenuCode.GDMarkerObjects1= [];
gdjs.MenuCode.GDMarkerObjects2= [];
gdjs.MenuCode.GDMarkerObjects3= [];
gdjs.MenuCode.GDBackground2Objects1= [];
gdjs.MenuCode.GDBackground2Objects2= [];
gdjs.MenuCode.GDBackground2Objects3= [];
gdjs.MenuCode.GDAbout_9595markerObjects1= [];
gdjs.MenuCode.GDAbout_9595markerObjects2= [];
gdjs.MenuCode.GDAbout_9595markerObjects3= [];


gdjs.MenuCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("About_marker"), gdjs.MenuCode.GDAbout_9595markerObjects2);
gdjs.copyArray(runtimeScene.getObjects("Marker"), gdjs.MenuCode.GDMarkerObjects2);
{for(var i = 0, len = gdjs.MenuCode.GDMarkerObjects2.length ;i < len;++i) {
    gdjs.MenuCode.GDMarkerObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.MenuCode.GDAbout_9595markerObjects2.length ;i < len;++i) {
    gdjs.MenuCode.GDAbout_9595markerObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Start"), gdjs.MenuCode.GDStartObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDStartObjects2.length;i<l;++i) {
    if ( gdjs.MenuCode.GDStartObjects2[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDStartObjects2[k] = gdjs.MenuCode.GDStartObjects2[i];
        ++k;
    }
}
gdjs.MenuCode.GDStartObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game", false);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("About"), gdjs.MenuCode.GDAboutObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.MenuCode.GDAboutObjects1.length;i<l;++i) {
    if ( gdjs.MenuCode.GDAboutObjects1[i].IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.MenuCode.GDAboutObjects1[k] = gdjs.MenuCode.GDAboutObjects1[i];
        ++k;
    }
}
gdjs.MenuCode.GDAboutObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "About", false);
}}

}


};gdjs.MenuCode.eventsList1 = function(runtimeScene) {

{


gdjs.MenuCode.eventsList0(runtimeScene);
}


};

gdjs.MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.MenuCode.GDTitleObjects1.length = 0;
gdjs.MenuCode.GDTitleObjects2.length = 0;
gdjs.MenuCode.GDTitleObjects3.length = 0;
gdjs.MenuCode.GDBackgroundObjects1.length = 0;
gdjs.MenuCode.GDBackgroundObjects2.length = 0;
gdjs.MenuCode.GDBackgroundObjects3.length = 0;
gdjs.MenuCode.GDStartObjects1.length = 0;
gdjs.MenuCode.GDStartObjects2.length = 0;
gdjs.MenuCode.GDStartObjects3.length = 0;
gdjs.MenuCode.GDAboutObjects1.length = 0;
gdjs.MenuCode.GDAboutObjects2.length = 0;
gdjs.MenuCode.GDAboutObjects3.length = 0;
gdjs.MenuCode.GDAbout_9595txtObjects1.length = 0;
gdjs.MenuCode.GDAbout_9595txtObjects2.length = 0;
gdjs.MenuCode.GDAbout_9595txtObjects3.length = 0;
gdjs.MenuCode.GDBackObjects1.length = 0;
gdjs.MenuCode.GDBackObjects2.length = 0;
gdjs.MenuCode.GDBackObjects3.length = 0;
gdjs.MenuCode.GDMarkerObjects1.length = 0;
gdjs.MenuCode.GDMarkerObjects2.length = 0;
gdjs.MenuCode.GDMarkerObjects3.length = 0;
gdjs.MenuCode.GDBackground2Objects1.length = 0;
gdjs.MenuCode.GDBackground2Objects2.length = 0;
gdjs.MenuCode.GDBackground2Objects3.length = 0;
gdjs.MenuCode.GDAbout_9595markerObjects1.length = 0;
gdjs.MenuCode.GDAbout_9595markerObjects2.length = 0;
gdjs.MenuCode.GDAbout_9595markerObjects3.length = 0;

gdjs.MenuCode.eventsList1(runtimeScene);
gdjs.MenuCode.GDTitleObjects1.length = 0;
gdjs.MenuCode.GDTitleObjects2.length = 0;
gdjs.MenuCode.GDTitleObjects3.length = 0;
gdjs.MenuCode.GDBackgroundObjects1.length = 0;
gdjs.MenuCode.GDBackgroundObjects2.length = 0;
gdjs.MenuCode.GDBackgroundObjects3.length = 0;
gdjs.MenuCode.GDStartObjects1.length = 0;
gdjs.MenuCode.GDStartObjects2.length = 0;
gdjs.MenuCode.GDStartObjects3.length = 0;
gdjs.MenuCode.GDAboutObjects1.length = 0;
gdjs.MenuCode.GDAboutObjects2.length = 0;
gdjs.MenuCode.GDAboutObjects3.length = 0;
gdjs.MenuCode.GDAbout_9595txtObjects1.length = 0;
gdjs.MenuCode.GDAbout_9595txtObjects2.length = 0;
gdjs.MenuCode.GDAbout_9595txtObjects3.length = 0;
gdjs.MenuCode.GDBackObjects1.length = 0;
gdjs.MenuCode.GDBackObjects2.length = 0;
gdjs.MenuCode.GDBackObjects3.length = 0;
gdjs.MenuCode.GDMarkerObjects1.length = 0;
gdjs.MenuCode.GDMarkerObjects2.length = 0;
gdjs.MenuCode.GDMarkerObjects3.length = 0;
gdjs.MenuCode.GDBackground2Objects1.length = 0;
gdjs.MenuCode.GDBackground2Objects2.length = 0;
gdjs.MenuCode.GDBackground2Objects3.length = 0;
gdjs.MenuCode.GDAbout_9595markerObjects1.length = 0;
gdjs.MenuCode.GDAbout_9595markerObjects2.length = 0;
gdjs.MenuCode.GDAbout_9595markerObjects3.length = 0;


return;

}

gdjs['MenuCode'] = gdjs.MenuCode;
